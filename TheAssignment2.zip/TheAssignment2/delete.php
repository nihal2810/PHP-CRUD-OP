<?php
if (isset($_GET["id"])){
    $id = $_GET["id"];

    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "nihal";
    //making connection to database..
    $connection = new mysqli($servername, $username, $password, $database);
    $sql= "DELETE FROM rinfo WHERE id=$id";
    $connection->query($sql);
}

header("location: /TheAssignment2/index.php");
exit;
?>